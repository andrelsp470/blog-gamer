# Controle Extra: blog de consoles e acessórios gamer

Blog estático (HTML + CSS, sem build) para divulgar produtos como afiliado.

## Antes de publicar
1. Troque `COLE-SEU-LINK-DE-AFILIADO-AQUI` pelos seus links de afiliado (busque no projeto inteiro).
2. Edite os textos dos posts e a página `sobre.html`.
3. Para mudar o nome do site, troque "Controle Extra" nos arquivos `.html`.

## Novo post
Copie um arquivo de `posts/`, edite o conteúdo e adicione um card em `index.html`.

## Publicar
- **GitHub Pages:** Settings, Pages, Branch `main`, pasta `/ (root)`.
- **Hostinger:** envie todo o conteúdo para `public_html`.

Mantenha o aviso de afiliado visível e o atributo `rel="sponsored"` nos links.
